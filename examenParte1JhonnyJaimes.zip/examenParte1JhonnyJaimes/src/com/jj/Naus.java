package com.jj;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Naus
{
    public static Set<Naus_Dades> setDeNaus = new LinkedHashSet<Naus_Dades>();

    public static void menu_1() {



        String str = "2001-12-01 23:45";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime dataTmp = LocalDateTime.parse(str, formatter);
        LocalDateTime today= LocalDateTime.now();

        setDeNaus.add(new Naus_Dades("Agamemnon", "destructor", "Omega", today, "Enviat a la flota de Babylon 5"));
        setDeNaus.add(new Naus_Dades("Achilles", "destructor", "Omega", today, "Enviat a la flota de Babylon 5"));
        setDeNaus.add(new Naus_Dades("Cortez", "explorador", "Explorer", dataTmp, "Enviat a l'espai profund"));
        setDeNaus.add(new Naus_Dades("Excalibur", "creuer pesat", "Hyperion", dataTmp, "Enviat a la flota de Babylon 5"));
        setDeNaus.add(new Naus_Dades("Prometheus", "creuer pesat", "Hyperion", dataTmp, "Enviat a la flota de Babylon 5"));
        setDeNaus.add(new Naus_Dades("Excalibur", "destructor", "Omega", today, "Enviat a la flota de Mart"));
        setDeNaus.add(new Naus_Dades("Orion", "destructor", "Omega", today, "Enviat a la flota de Mart"));
        setDeNaus.add(new Naus_Dades("Nimrod", "destructor", "Omega", today, "Enviat a la flota de Mart"));


         //System.out.println(setDeNaus);
    }

    //public static void main(String[] arg)
    public static void menu_2()
    {
        PriorityQueue<String> nausOrdenades = new PriorityQueue<>();


        for (Naus_Dades datos : setDeNaus)
        {
            nausOrdenades.add(datos.getNom() + ": "+ datos.getTipus() + " del model " + datos.getModel() + " construit el " + datos.getDataConstruccio() + ". Descripcio: "+ datos.getDescripcio()+ "\n");
        }

        System.out.println(nausOrdenades);


    }

    //public  static int existeix=0;

    public static boolean menu_11()
    {
        System.out.println("introdueix: ");
        System.out.println("nom, tipus, model, data construcció i descripció");

        Scanner in = new Scanner(System.in);
        System.out.print("Nom: ");
        String nom = in.next();
        System.out.print("Tipus: ");
        String tipus = in.next();
        System.out.print("Model: ");
        String model = in.next();

        System.out.print("Data de construccio (AAAA-MM-DD): ");
        String data1 = in.next();
        data1 = data1+ " 00:01";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime dataConstruccio = LocalDateTime.parse(data1, formatter);

        System.out.print("Descripcio: ");
        String descripcio = in.next();


                /*
        for (Naus_Dades datos : setDeNaus)
        {
            if (nom.equals(datos.getNom()))
            {
                existeix++;
            }
            if (tipus.equals(datos.getTipus())){
                existeix++;
            }
            if (model.equals(datos.getModel())) {
                existeix++;
            }

            if (existeix==3) {
                break;
            }
            else{ existeix= 0;}
        }
                 */
        if (setDeNaus.contains(nom) && setDeNaus.contains(tipus) && setDeNaus.contains(model)) {
            System.out.println("ERROR: NO S'HA INTRODUIT PER DUPLICAT");
            return false;
        }
        else
        {
            setDeNaus.add(new Naus_Dades(nom, tipus, model, dataConstruccio, descripcio));
            return true;
        }
    }

    //public static void main(String[] arg)
    public static void numNausVsTipus()
    {
        menu_1();
        HashMap<String, Integer> contador = new HashMap<>();

        for (Naus_Dades datos : setDeNaus) {
            int cont = 0;
            contador.put(datos.tipus, cont++);

        }
        System.out.println(contador);

    }

}
