/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen_2019_2020_DAM;

import java.util.ArrayList;

/**
 *
 * @author gmartinez
 */
public class Khom_Nikel_ObjecteMenu {
    ArrayList<Objectiu_Dades> llistaObjectius;
    ArrayList<ObjectiuTipus_Dades> llistaObjectiusTipus;
}
